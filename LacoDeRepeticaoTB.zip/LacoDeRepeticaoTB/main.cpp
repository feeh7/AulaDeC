#include <iostream>
#include <stdlib.h>

using namespace std;

void somar()
{
    double valor = 0;
    int qtd = 0;
    double resultado = 0;

    //perguntar quantidade de numeros
    cout << "quantos numeros se vai somar: ";
    cin >> qtd;

    //usar repeti��o com la�o for
    for(int i = 1; i <= qtd; i++)
    {
        //pra cada repeti��o eu pergunto o numero a ser somado
        cout << "Numero : " << i << ":";
        cin >> valor;
        resultado += valor;
    }

    //somar o valor em uma variavel totalizadora



    //escrever o valor da variavel totalizador

    cout << "o valor da soma e " << resultado << endl;
}

void fatorial()

{
    long numerofator = 0;
    unsigned long resultadofator = 1;


    //perguntar quantidade de numeros
    cout << "qual n�mero ser� fatorado: ";
    cin >> numerofator;

    //usar repeti��o com la�o for
    for(int i = numerofator; i >= 1 && i <= numerofator ; i--)
       resultadofator *= i;
        cout << "o valor da fatoracao e " << resultadofator << endl;






}

int main()
{
    char opcao = '0';
    char prosseguir = 'S';

    while(true)
    {
        system("cls");

        cout << "************************" << endl;
        cout << "MINHA CALCULADORA C/C++" << endl;
        cout << "************************\n" << endl;

        cout << "(1) Adicao" << endl;
        cout << "(2) Subtracao" << endl;
        cout << "(3) Multiplicacao" << endl;
        cout << "(4) Divisao\n" << endl;
        cout << "(5) Fatorial\n" << endl;
        cout << "(A) Sair\n" << endl;

        cout << "Escolha uma operacao:";
        cin >> opcao;

        switch(opcao)
        {
            case '1': somar();
                break;
            case '2': cout << "Subtraindo..." << endl;
                break;
            case '3': cout << "Multiplicando..." << endl;
                break;
            case '4': cout << "Dividindo..." << endl;
                break;
            case '5': fatorial();
                break;
            case 'A': return 0;
                break;
            default: cout << "Opcao Invalida" << endl;
                break;
        }

        cout << "Deseja continuar ? (S/N) " << endl;
        cin >> prosseguir;

        if(prosseguir != 'S' && prosseguir != 's')
            return 0;

    }

    return 0;
}
